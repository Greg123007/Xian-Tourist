<?php
	session_start();

	if(isset($_POST["submit"]) && isset($_POST["submit"]) == "Submit"){
	//get information
	//-------------------------------

		$user_name = $_POST['username'];
		
		$user_id = $_POST['userid'];
	    
	    $user_password = $_POST['password'];
	  	
	  	$user_phone = $_POST['phone'];
	  
	    $user_email = $_POST['email'];
		
	//write to userInfo
	//-----------------------------
		$file = fopen("userInfo.txt", "a");
	/*  		 name          account*/
		$info = $user_name." ".$user_id." ".$user_password." ".$user_phone." ". $user_email." ";
		fwrite($file, "{$info}\r\n");
		fclose($file);
	}

	//checkid(optional)
	//-----------------------------

	header("Refresh: 0;url =login.html");
	// echo "<p><a href='http://localhost/Xian-Tourist/Home/home.html'>Back</a></p>";
?>



