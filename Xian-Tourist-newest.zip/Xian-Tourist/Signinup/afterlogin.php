<?php
session_start();
$name = $_SESSION["yourname"];
$email = $_SESSION["youremail"];
$phoneNum = $_SESSION["yourphoneNum"];
$account = $_SESSION["youraccount"];



//echo "$name";
?>

<!DOCTYPE html>
<html leng="en">
<head>
	<meta charset="utf-8">
	<title>user profile</title>
	<link rel="stylesheet" type="text/css" href="sign inup.css">
  <!--FONTS-->
 <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@400;700&display=swap" rel="stylesheet">

	</head>
	
	<body>
	<header>
			<div class="main">
				<div class="logo">
					<img class="logo" src="sunshine.png">
				</div>
				<ul>
					<li class="#"><a href="#">Home</a></li>
					<li><a href="#">About</a></li>
					<li class="active"><a href="#">Sign up/in</a></li>
					<li><a href="#">Travel Plan</a></li>
					<li><a href="#">Hotel</a></li>
					<li><a href="#">Play & Eat</a></li>				
				</ul>
				
			</div>	
		</header>	
		
			
			

		<div class="container">
			<fieldset>
				<table border ="1">
					<tr>	
						<td><h2>Welcome to Sunshine travel agency</h2></td>
					</tr>
					<tr>
						<td>
							<img src="Usericon.svg">			
						</td>
					</tr>
					<tr>
						<td><span class="user name"><?php echo "$name" ?></span></td>
					</tr>
					<tr>
						<td>
							<?php echo "$account";?>
						</td>





					</tr>


						
						
					
				






				





					

				</table>
			</fieldset>


		</div>


	</body>
	</html>