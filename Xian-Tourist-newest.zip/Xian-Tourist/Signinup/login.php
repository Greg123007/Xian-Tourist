<?php
	session_start();
	
	if(isset($_POST['login']) && $_POST['login'] == 'login'){
		
		$post_userId = $_POST['userId'];
		$post_password = $_POST['password'];
		
		
		$YON = 0;
		$file = file("userInfo.txt");

		foreach ($file as $line) {
			$detail = explode(' ', $line);
			if($detail[1] == $post_userId && $detail[2] == $post_password){
				$YON = 1;
				$yourname = $detail[0];
				$youraccount = $detail[1];
				$yourphoneNum = $detail[3];
				$youemail = $detail[4];

				break;
			}else{
				$YON = 0;
				
			}
		}
		
		if ($YON == 1) {
			$_SESSION["yourname"] = $yourname;
			$_SESSION["youraccount"] =$youraccount;
			$_SESSION["yourphoneNum"] =$yourphoneNum;
			$_SESSION["youremail"] = $youremail;

			echo "Succesfully login. Welcome <br>".$_SESSION["yourname"];
			echo"<p><a href='http://localhost/Xian-Tourist/Home/home.html'>Back</a></p>";
		}
		else{
			echo "<script>alert('Please try again.')</script>";
		}	
	}
?>