<?php
session_start();
if (!isset($_SESSION["cartItems"])) {
    $_SESSION["cartItems"] = 0;
}

// This function will retrieve data relating to a specific book
// It should be called using the $db object and one bookId
// It will return one array containing fields for the specified book
function getBookDetails($bookId){
    if ($bookId > 5) {
        $path = "data/scenery.txt";
        $file = fopen($path, "r");
        $data = array();
        $i = 0;
        while(! feof($file))
        {
            $data[$i]= fgets($file);
            $i++;
        }
        fclose($file);
        $data=array_filter($data);
        foreach($data as $k=>$v){
            $str = explode("|",$v);
            if ($str[0] == $bookId){
                $row[0] = $str[1];
                $row[1] = $str[2];
                break;
            }
        }
    } else {
        $path_h = "data/hotel.txt";
        $file_h = fopen($path_h, "r");
        $data_h = array();
        $i_h = 0;
        while(! feof($file_h))
        {
            $data_h[$i_h]= fgets($file_h);
            $i_h++;
        }
        fclose($file_h);
        $data_h=array_filter($data_h);
        foreach($data_h as $k=>$v){
            $str_h = explode("|",$v);
            if ($str_h[0] == $bookId){
                $row[0] = $str_h[1];
                $row[1] = $str_h[4];
            }
        }
    }
    return $row;
}

?>