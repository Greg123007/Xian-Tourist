<!--这个文件暂时没有用-->

<?php
$path = "data/scenery.txt";
$file = fopen($path, "r");
$data = array();
$i = 0;
while(! feof($file))
{
    $data[$i]= fgets($file);
    $i++;
}
fclose($file);
$data=array_filter($data);
$a = 0;
$b = 0;
foreach($data as $k=>$v){
    $str = explode("|",$v);
    if ($str[3] == "Insurance"){
        $str_arr1[$a] = $str;
        $a++;
    }else{
        $str_arr2[$b] = $str;
        $b++;
    }
}
$path_h = "data/hotel.txt";
$file_h = fopen($path_h, "r");
$data_h = array();
$i_h = 0;
while(! feof($file_h))
{
    $data_h[$i_h]= fgets($file_h);
    $i_h++;
}
fclose($file_h);
$data=array_filter($data_h);
foreach($data_h as $k=>$v){
    $str_h_arr[$k] = explode("|",$v);
}

function getHotelInfo($id, $str_h_arr){
    $str = [];
    foreach ($str_h_arr as $str_k=>$str_v){
        if ($id == $str_v[0]){
            $str = $str_v;
            break;
        }
    }
    return $str;
}