<?php
include('public.php');

//判断是否有要添加的物品，有的话，判断当前购物车是否有物品，有物品判断是否和添加物品一样，一样则自增
$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
if (isset($_GET['bookId'])) {
    if (count($cart) > 0) {
        for ($i = 0; $i < count($cart); $i++) {
            if ($cart[$i]['id'] == $_GET['bookId']) {
                $cart[$i]['quantity'] += 1;
                $_SESSION["cartItems"] += 1;
                $exist = true;
            }
        }
    }

    if (!isset($exist)) {
        $bookDetails = getBookDetails($_GET['bookId']);
        array_push($cart, array("id" => $_GET['bookId'], "title" => $bookDetails[0], "price" => $bookDetails[1], "quantity" => 1));
        $_SESSION["cartItems"] += 1;
    }
    $_SESSION['cart'] = $cart;
}
if (isset($_GET['changeBookId'])) {
    for ($i = 0; $i < count($cart); $i++) {
        if ($cart[$i]['id'] == $_GET['changeBookId']) {
            $_SESSION["cartItems"] += ($_GET['quantity'] - $cart[$i]['quantity']);
            $cart[$i]['quantity'] = $_GET['quantity'];
        }
    }
    $_SESSION['cart'] = $cart;
}
   if (isset($_GET['clearCart']) && $_GET['clearCart'] == 1) {

                    session_destroy();
                    $_SESSION["cartItems"] = 0;
                }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Shopping Cart</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="css/Shopping Cart.css">
<!--FONTS-->
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@400;700&display=swap" rel="stylesheet">
</head>

<body>
<header>
  <div class="main">
    <div class="logo"> <img class="logo" src="images/sunshine.png"> </div>
    <ul>
      <li class="#"><a href="http://localhost/Xian-Tourist/Home/home.html">Home</a></li>
      <li><a href="http://localhost/Xian-Tourist/About/about.php">About</a></li>
      <li><a href="http://localhost/Xian-Tourist/Signinup/signinup.html">Sign up/in</a></li>
      <li><a href="TravelPlan.php">Travel Plan</a></li>
      <li><a href="accommodation.php">Hotel</a></li>
      <li><a href="attractions.php">Views & Eat</a></li>
    </ul>
    <div class="cart"><a href="ShoppingCart.php"><img src="images/cart.png" alt="cart"></a>Shopping Cart <span class="red">(<?php echo $_SESSION["cartItems"] ?> )</span></div>
  </div>
  <br/>
  <br/>
  <br/>
  <br/>
  <br/>
</header>
<div class="container">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <caption>
      Your Shopping Cart
      </caption>
      <?php



                if ($_SESSION["cartItems"] > 0) {
                    ?>
      <tr>
        <th>Title</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Total Price</th>
      </tr>
      <?php
        $totalPrice = 0;
        for ($i = 0; $i < count($_SESSION['cart']); $i++) {
            $totalPrice += $_SESSION['cart'][$i]["price"] * $_SESSION['cart'][$i]["quantity"];
            $_SESSION["totalPrice"] = $totalPrice;
            ?>
            <tr>
                <td><?= $_SESSION['cart'][$i]["title"] ?></td>
                <td class="nub">
                    <form action="ShoppingCart.php" method="get">
                        <input type="hidden" name="changeBookId"
                               value="<?= $_SESSION['cart'][$i]["id"] ?>"></input>
                        <input type="number" value="<?= $_SESSION['cart'][$i]["quantity"] ?>"
                               name="quantity" min="1">
                        <button type="submit">Update</button>
                    </form>
                </td>
                <td>$<?= $_SESSION['cart'][$i]["price"] ?></td>
                <td>$<?= $_SESSION['cart'][$i]["price"] * $_SESSION['cart'][$i]["quantity"] ?></td>
            </tr>

            <?php
        }
        ?>
      <!-- <tr>
        <td>Shaanxi History Museum</td>
        <td class="nub"><span>1</span>
          <button>update</button></td>
        <td>$10.99</td>
        <td>$10.99</td>
      </tr>-->
      <tr class="rst">
        <td colspan="3">You have <?= $_SESSION["cartItems"] ?> items in the cart</td>
        <td>Cart Total:$<?= $totalPrice ?></td>
      </tr> 
      <?php
                } else {
                    echo "<tr><th colspan='4'>Your cart is empty</td></tr>";
                }
                ?>
      <tr class="operation">
        <?php
          if ($_SESSION["cartItems"] == 0) {

            ?>
            <td><button onClick="Continue();">Continue Shopping</button></td>
          <?php 
          } else {
            ?>
            <td><button onClick="Clear();">Clear Cart</button></td>
        <td colspan="2"><button onClick="Checkout();">Proceed to Checkout</button></td>
        <td><button onClick="Continue();">Continue Shopping</button></td>
          <?php }
        ?>
        
      </tr>
    </table>
</div>
</body>
<script>
  function Clear() {
  window.location.href = "ShoppingCart.php?clearCart=1";
}
function Checkout() {
  window.location.href = "checkout.php";
}
function Continue() {
  window.location.href = "accommodation.php";
}
</script>
</html>