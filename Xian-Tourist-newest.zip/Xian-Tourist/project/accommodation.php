<?php
session_start();
if (!isset($_SESSION["cartItems"])) {
    $_SESSION["cartItems"] = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Hotel</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="css/Hotel.css">
<!--FONTS-->
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin=""/>
 <script src="./js/jquery.js"></script>
</head>
<body>
<header>
  <div class="main">
    <div class="logo"> <img class="logo" src="images/sunshine.png"> </div>
    <ul>
      <li class="#"><a href="http://localhost/Xian-Tourist/Home/home.html">Home</a></li>
      <li><a href="http://localhost/Xian-Tourist/About/about.php">About</a></li>
      <li><a href="http://localhost/Xian-Tourist/Signinup/signinup.html">Sign up/in</a></li>
      <li><a href="TravelPlan.php">Travel Plan</a></li>
      <li class="active"><a href="accommodation.php">Hotel</a></li>
      <li><a href="attractions.php">Views & Eat</a></li>
    </ul>
    <div class="cart"><a href="ShoppingCart.php"><img src="images/cart.png" alt="cart"></a>Shopping Cart <span class="red">(<?php echo $_SESSION["cartItems"] ?> )</span></div>
  </div>
  <form>
    <div class="PeopleSize">
      <div>
        <label for="People" style="font: normal bolder 15px 'Source Sans Pro', sans-serif;">Guest:</label>
        <br>
        <select name="People" id="People">
          <option value="one adult" >one adult</option>
          <option value="two adult" >two adult</option>
          <option value="two adult with children">two adult with children</option>
        </select>
      </div>
      <div>
        <label for="day" style="font: normal bolder 15px 'Source Sans Pro', sans-serif;">Check in:<br>
        </label>
        <input type="date" id="day" name="day" >
      </div>
      <div>
        <label for="day" style="font: normal bolder 15px 'Source Sans Pro', sans-serif;">Check out:<br>
        </label>
        <input type="date" id="day" name="day" >
      </div>
      <div>
        <button id="search" onclick="goToHotel()" style="font: normal bolder 14px 'Source Sans Pro', sans-serif;">search</button>
      </div>
    </div>
  </form>
</header>
<?php
$path = "data/hotel.txt";
$file = fopen($path, "r");
$data = array();
$i = 0;
while(! feof($file))
{
    $data[$i]= fgets($file);
    $i++;
}
fclose($file);
$data=array_filter($data);
foreach($data as $k=>$v){
    $str_arr[$k] = explode("|",$v);
}
foreach ($str_arr as $str_k=>$str_v){
?>
<div class="Hotel">
  <div class="img"> <a target="_blank" href="https://media-cdn.tripadvisor.com/media/photo-o/0c/f3/70/fb/caption.jpg"> <img src="images/<?php echo $str_v[5] ?>" alt="images" width="300" height="200" align="top"> </a>
    <div class="desc">
      <!-- <p id="1"></p> -->
      <input type="hidden" id="hotelid" name="hotelid" value="<?php echo $str_v[0] ?>">
      <p style="color:#656567;font: normal bolder 30px 'Source Sans Pro', sans-serif;"><?php echo $str_v[1] ?></p>
      <p class="like"> &#9829;</p>
      <?php if ($i == 1) {
        ?><p style="font-size:20px;text-decoration: line-through; "> C$ 56</p>
        <?php
      }
      ?>
      <br/>
      <p style="font-size:40px;text-decoration: underline; color: #FF5733"> C$ <?php echo $str_v[4] ?></p>
      <br/>
      <button style=" height: 20px; width: 80px" onclick="checkMore()">Check More</button><button class="add" onclick="add(<?php echo $str_v[0] ?>)">add to cart</button>
      <br>
      <br>
      <p style="color: #F08080"> &#9733;&#9733;&#9733;&#9733;&#9733;<?php echo $str_v[4] ?> reviews</p>
      <?php echo $str_v[2] ?> <br/>
      </p>
    </div>
  </div>
</div>
<?php  }?>
<!-- <div class="Hotel">
  <div class="img"> <a target="_blank" href="https://media-cdn.tripadvisor.com/media/photo-m/1280/1c/2d/cc/37/caption.jpg"> <img src="images/Renaissance Xi'an Hotel.jpg" alt="images" width="300" height="200"> </a>
    <div class="desc">
      <p id="2"></p>
      <p style="color:#656567;font: normal bolder 30px 'Source Sans Pro', sans-serif;">Renaissance Xi'an Hotel</p>
      <p class="like"> &#9829;</p>
      <p style="font-size:40px; color: #FF5733" > C$ 58</p>
      <br/>
      <button style=" height: 20px; width: 80px" onclick="checkMore()">Check More</button><button class="add">add to cart</button>
      <br>
      <br>
      <p style="color: #F08080"> &#9733;&#9733;&#9733;&#9733;&#9733;888 reviews</p>
      <p> No.355 Huixin Road, Qujiang New Area, Xi'an 710065 China</p>
    </div>
  </div>
</div>
<div class="Hotel">
  <div class="img"> <a target="_blank" href="https://media-cdn.tripadvisor.com/media/photo-o/0a/f1/43/3a/getlstd-property-photo.jpg"> <img src="images/Renaissance Xi'an Hotel2.jpg" alt="Renaissance Xi'an Hotel2" width="300" height="200"> </a>
    <div class="desc">
      <p id="3"> </p>
      <p style="color:#656567;font: normal bolder 30px 'Source Sans Pro', sans-serif;">Renaissance Xi'an Hotel</p>
      <p class="like"> &#9829;</p>
      <p style="font-size:40px; color: #FF5733" > C$ 58</p>
      <br/>
      <button style=" height: 20px; width: 80px" onclick="checkMore()">Check More</button><button class="add">add to cart</button>
      <br>
      <br>
      <p style="color: #F08080"> &#9733;&#9733;&#9733;&#9733;&#9733;888 reviews</p>
      <p> No.355 Huixin Road, Qujiang New Area, Xi'an 710065 China</p>
    </div>
  </div>
</div>
<div class="Hotel">
  <div class="img"> <a target="_blank" href="https://media-cdn.tripadvisor.com/media/photo-m/1280/1b/7d/35/47/exterior.jpg"> <img src="images/HUALUXE Xi'an Tanghua.jpg" alt="图片文本描述" width="300" height="200"> </a>
    <div class="desc">
      <p id="4"></p>
      <p style="color:#656567;font: normal bolder 30px 'Source Sans Pro', sans-serif;">HUALUXE Xi'an Tanghua</p>
      <p class="like"> &#9829;</p>
      <p style="font-size:40px; color: #FF5733" > C$ 58</p>
      <br/>
      <button style=" height: 20px; width: 80px" onclick="checkMore()">Check More</button><button class="add">add to cart</button>
      <br>
      <br>
      <p style="color: #F08080"> &#9733;&#9733;&#9733;&#9733;&#9733;888 reviews</p>
      <p> No.40, Yanyin Road, Qujiang New District, Xi'an 710061 China</p>
    </div>
  </div>
</div>
<div class="Hotel">
  <div class="img"> <a target="_blank" href="https://media-cdn.tripadvisor.com/media/photo-m/1280/1b/7d/35/47/exterior.jpg"> <img src="images/W hotel in Xi'an.jpg" alt="W hotel in Xi'an" width="300" height="200"> </a>
    <div class="desc">
      <p id="abc"></p>
      <p style="color:#656567;font: normal bolder 30px 'Source Sans Pro', sans-serif;">W hotel in Xi'an</p>
      <p class="like"> &#9829;</p>
      <p style="font-size:40px; color: #FF5733" > C$ 58</p>
      <br/>
      <button style=" height: 20px; width: 80px" onclick="checkMore()">Check More</button><button class="add">add to cart</button>
      <br>
      <br>
      <p style="color: #F08080"> &#9733;&#9733;&#9733;&#9733;&#9733;888 reviews</p>
      <p> No.40, Yanyin Road, Qujiang New District, Xi'an 710061 China</p>
    </div>
  </div>
</div>
<div class="Hotel">
  <div class="img"> <a target="_blank" href="https://media-cdn.tripadvisor.com/media/photo-m/1280/1b/7d/35/47/exterior.jpg"> <img src="images/Westin.jpg" alt="Westin hotel" width="300" height="200"> </a>
    <div class="desc">
      <p id="6"></p>
      <p style="color:#656567;font: normal bolder 30px 'Source Sans Pro', sans-serif;">Westin Hotel</p>
      <p class="like"> &#9829;</p>
      <p style="font-size:40px; color: #FF5733" > C$ 58</p>
      <br/>
      <button style=" height: 20px; width: 80px" onclick="checkMore()">Check More</button><button class="add">add to cart</button>
      <br>
      <br>
      <p style="color: #F08080"> &#9733;&#9733;&#9733;&#9733;&#9733;888 reviews</p>
      <p> No.40, Yanyin Road, Qujiang New District, Xi'an 710061 China</p>
    </div>
  </div>
</div> -->
<div class="sort">
  <button onclick="Default();">Default</button>
  <button onclick="price();">Sort by price</button>
</div>
<div class="right"> <br>
  <br>
  <label for="oo">Popular:</label>
  <br>
  <br>
  <br>
  <input type="checkbox" id="start" name="oo" value="start">
  <label for="start">5 stars</label>
  <br>
  <input type="checkbox" id="Breakfast" name="oo" value="Breakfast">
  <label for="Breakfast">Breakfast included</label>
  <br>
  <input type="checkbox" id="Air" name="oo" value="Air">
  <label for="Air">Air conditioning</label>
  <br>
  <br>
  <br>
  <HR style="border:3 double #987cb9" width="100%" color=#ccc SIZE=3>
  <br>
  <br>
  <label for="oo">Features:</label>
  <br>
  <br>
  <input type="checkbox" id="Amenities" name="Amenities" value="Amenities">
  <label for="Amenities">Amenities</label>
  <br>
  <input type="checkbox" id="Wifi" name="Wifi" value="Wifi">
  <label for="Wifi">Free Wifi</label>
  <br>
  <input type="checkbox" id="Pool" name="Pool" value="Pool">
  <label for="Pool">Pool</label>
  <br>
  <input type="checkbox" id="parking" name="parking" value="parking">
  <label for="parking">Free parking</label>
  <br>
  <br>
  <HR style="border:3 double #987cb9" width="100%" color=#ccc SIZE=3>
  <button id="ChooseP1" onclick="ChooseP();" style="font: normal bolder 15px 'Source Sans Pro', sans-serif; ">search</button>
</div>
</body>

<script type="text/javascript">
   
function Default() {
  window.location.href = "accommodation.php?order=id";
}
function price() {
  window.location.href = "accommodation.php?order=price";
}
function add(id) {
  window.location.href = "ShoppingCart.php?bookId="+id;
}
         
     
    function goToHotel() {
               
        var select =document.getElementById("People");
       

           if (select.value== "one adult") {
               window.location.hash = "#6";
           }
            else if (select.value== "two adult") {
               window.location.hash = "#1";
           }

            else if (select.value== "two adult with children") {
               window.location.hash = "#3";
           }


          
            
}

      


      function ChooseP(){
        var start =document.getElementById("start");
        var Breakfast =document.getElementById("Breakfast");

           if (start.checked==true) {
               window.location.hash = "#6";
           }
            else if (Breakfast.checked==true) {
               window.location.hash = "#1";
           }

           else{
            window.location.hash = "#3";
           }
           

      }





    function changeColor()
{
    document.getElementById("button").style.background= "red";
}
  
  function checkMore()
  {
  window.open('http://www.google.com');
  }



 //map

</script>
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin="">

        
            
        var mymap =null;        
        </script>
<div id="mapid" style="width: 200px; height: 200px; position:absolute;
      left:1100px;top:68%;"></div>
<p style="color:#656567;font-family:arial;font-size:30px;left:1100px;top:62%; position:absolute;">View Map</p>
<script type="text/javascript">
            
            //Initialize Map    
            var Lat = 34.3194333;
            var Long = 108.9426544;
            
            //mapid is the id for your div element
            //You can leave the rest as it is
            mymap = L.map('mapid').setView([Lat, Long], 10);            
            L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
            maxZoom: 18,
            attribution: 'Map data &copy; <a href=" ">OpenStreetMap</a > contributors, ' +
                '<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a >, ' +
                'Imagery © <a href="https://www.mapbox.com/">Mapbox</a >',
            id: 'mapbox/streets-v11',
            tileSize: 512,
            zoomOffset: -1
        }).addTo(mymap);

            var marker = L.marker([34.3194333,108.9426544]).addTo(mymap);
            marker.bindPopup("<b>Novotel Xian SCPG </b>").openPopup();

            var marker = L.marker([34.2795641,108.9576984]).addTo(mymap);
            marker.bindPopup("<b>Renaissance Xi'an Hotel</b>").openPopup();

               
   </script>
<script>
        $(function () {
            $(".like").click(function () {
                $(this).toggleClass('like-A');
            })
        })
    </script>
</html>
