<?php
session_start();
if (!isset($_SESSION["cartItems"])) {
    $_SESSION["cartItems"] = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Travel Plan</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="css/TravelPlan.css">
<!--FONTS-->
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>
<header>
  <div class="main">
    <div class="logo"> <img class="logo" src="images/sunshine.png"> </div>
    <ul>
      <li class="#"><a href="http://localhost/Xian-Tourist/Home/home.html">Home</a></li>
      <li><a href="http://localhost/Xian-Tourist/About/about.php">About</a></li>
      <li><a href="http://localhost/Xian-Tourist/Signinup/signinup.html">Sign up/in</a></li>
      <li class="active"><a href="TravelPlan.php">Travel Plan</a></li>
      <li><a href="accommodation.php">Hotel</a></li>
      <li><a href="attractions.php">Views & Eat</a></li>
    </ul>
    <div class="cart"><a href="ShoppingCart.php"><img src="images/cart.png" alt="cart"></a>Shopping Cart <span class="red">(<?php echo $_SESSION["cartItems"] ?> )</span></div>
  </div>
  <br/>
  <br/>
  <br/>
  <br/>
  <br/>
</header>
<div id="Tripdeals">
  <P style="color:black; font-weight:bolder; margin:2% auto; text-align:center; font-size:35px; font-family:'Source Sans Pro', sans-serif;"> Trip Deals</P>
</div>
<div class="grid-contanier">
<?php
        $path = "data/scenery.txt";
        $file = fopen($path, "r");
        $data = array();
        $i = 0;
        while(! feof($file))
        {
            $data[$i]= fgets($file);
            $i++;
        }
        fclose($file);
        $data=array_filter($data);
        $a = 0;
        $b = 0;
        foreach($data as $k=>$v){
            $str = explode("|",$v);
            if ($str[3] == "Insurance"){
                $str_arr1[$a] = $str;
                $a++;
            }else{
                $str_arr2[$b] = $str;
                $b++;
            }
        }

foreach ($str_arr2 as $str_k=>$str_v){
?>
  <div class="r3c3"> <a class="img" href="#"  alt="Mausoleum of the First Qin Emperor one day trip"/><img src="images/<?php echo $str_v[4] ?>" height="150" width="250"> </a>
    <p style="color:black; font-size:20px;"><?php echo $str_v[1] ?></p>
    <p style="color:black; font-size:20px;">Price: <?php echo $str_v[2] ?></p>
    <p style="font-size:10px; color: red"> &#9733; &#9733; &#9733; &#9733; &#9733;  <?php echo $str_v[3] ?>  reviews</p>
    <button type="submit" class="btn" name="add" onclick="add(<?php echo $str_v[0] ?>)"> Add to cart </button>
  </div>
  <?php }?>
  <div class="empty">
    <p></p>
  </div>
</div>

<hr>
<br>
<P style="color:black; font-weight:bolder; margin:2% auto; text-align:center; font-size:35px; font-family:'Source Sans Pro', sans-serif;"> Travel Insurance</P>
<br>
<div class="grid-contanier2">
  <?php
  foreach ($str_arr1 as $str_k=>$str_v){
?>
    <div class="r1c1"> </a>
      <p style="color:black; font-size:20px;"><?php echo $str_v[1] ?></p>
      <p style="color:black; font-size:20px;">Price: <?php echo $str_v[2] ?> per day</p>
      <p style="font-size:10px";></p>
      <button type="submit"  class="btn" name="add" onclick="add(<?php echo $str_v[0] ?>)"> Add to cart </button>
    </div>
  <?php  } ?>
  <!-- <form action="index.php" method="post">
    <div class="r1c1"> </a>
      <p style="color:black; font-size:20px;"> Travel Insurance For Student </p>
      <p style="color:black; font-size:20px;">Price: 5.99 per day</p>
      <p style="font-size:10px;" ></p>
      <button type="submit" class="btn" name="add"> Add to cart </button>
    </div>
  </form> -->
</div>
<script type="text/javascript">
  function add(id) {
  window.location.href = "ShoppingCart.php?bookId="+id;
}
</script>
</body>
</html>